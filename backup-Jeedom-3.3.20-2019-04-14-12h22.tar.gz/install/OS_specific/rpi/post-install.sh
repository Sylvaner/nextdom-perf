#!/bin/sh
sed -i 's/127.0.0.1 raspberrypi/127.0.0.1 jeedom/g' /etc/hosts > /dev/null 2>&1