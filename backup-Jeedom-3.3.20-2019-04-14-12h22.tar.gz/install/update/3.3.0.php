<?php
shell_exec('sudo apt-get -y install duplicity');
