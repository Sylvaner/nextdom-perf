<?php
exec('sudo apt-get install -y xauth');