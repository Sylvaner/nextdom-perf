ALTER TABLE scenario ADD `order` INT NULL;
